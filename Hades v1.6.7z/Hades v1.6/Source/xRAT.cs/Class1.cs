﻿using System;
using System.Windows.Forms;

internal class Class1
{
    private static bool bool_0;

    internal static void QaIGh5M7cuigS()
    {
        if (!bool_0)
        {
            bool_0 = true;
            MessageBox.Show("This assembly is protected by an unregistered version of Eziriz's \".NET Reactor\"!");
        }
    }
}

