﻿Imports Microsoft.VisualBasic.Devices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics

<EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")> _
Friend Class Class10
    Inherits Computer
    ' Methods
    <DebuggerHidden, EditorBrowsable(EditorBrowsableState.Never)> _
    Public Sub New()
        Class1.QaIGh5M7cuigS
    End Sub

End Class


