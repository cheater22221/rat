﻿' Assembly xRAT, Version 1.0.0.0

<Assembly: System.Reflection.AssemblyKeyName("")>
<Assembly: System.Reflection.AssemblyDelaySign(False)>
<Assembly: System.Reflection.AssemblyTitle("")>
<Assembly: System.Runtime.InteropServices.ComVisible(False)>
<Assembly: System.Reflection.AssemblyConfiguration("")>
<Assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)>
<Assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.None)>
<Assembly: System.Reflection.AssemblyCopyright("Copyright " & ChrW(169) & " Had" & ChrW(232) & "s RAT 2012")>
<Assembly: System.Reflection.AssemblyDescription("")>
<Assembly: System.Reflection.AssemblyCompany("")>
<Assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows:=True)>
<Assembly: System.Runtime.InteropServices.Guid("736f1cfb-607e-4891-bed9-1509a4cab8d5")>
<Assembly: System.Reflection.AssemblyTrademark("")>
<Assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")>
<Assembly: System.Reflection.AssemblyProduct("")>

