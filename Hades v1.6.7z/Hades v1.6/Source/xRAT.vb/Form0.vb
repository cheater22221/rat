﻿Imports Microsoft.VisualBasic.ApplicationServices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

<EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")> _
Friend Class Form0
    Inherits WindowsFormsApplicationBase
    ' Methods
    <DebuggerStepThrough> _
    Public Sub New()
        MyBase.New(AuthenticationMode.Windows)
        Me.IsSingleInstance = False
        Me.EnableVisualStyles = True
        Me.SaveMySettingsOnExit = True
        Me.ShutdownStyle = ShutdownMode.AfterMainFormCloses
    End Sub

    <MethodImpl(MethodImplOptions.NoOptimization), EditorBrowsable(EditorBrowsableState.Advanced), DebuggerHidden, STAThread> _
    Friend Shared Sub Main(ByVal args As String())
        Try 
            Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering)
            Class1.QaIGh5M7cuigS
        End Try
        Class2.Form0_0.Run(args)
    End Sub

    <DebuggerStepThrough> _
    Protected Overrides Sub OnCreateMainForm()
        Me.MainForm = Class2.Class4_0.method_6
    End Sub

End Class


